#ifndef _WATER_H_
#define _WATER_H_

#include "core.h"

class Water
	:public Core
{
protected:

public:
	Water();
	Water(int m_Z, int m_N);
};

#endif