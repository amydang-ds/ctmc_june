#ifndef _VECTOR_H_
#define _VECTOR_H_

#include <math.h>
#include <iostream>
using namespace std;

class Vector
{
public:
	double x, y, z;

	Vector();
	Vector(double m_x, double m_y, double m_z);

	Vector operator-(const Vector& V);
	Vector operator+(const Vector& V);
	Vector operator*(double d);
	Vector operator*(const Vector& V);

	void set(double m_x, double m_y, double m_z);
	double module();
	double square();

	void in();
	void out();
};

#endif