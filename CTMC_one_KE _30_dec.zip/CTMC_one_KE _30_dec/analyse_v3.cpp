#include <fstream>
#include <iostream>
#include <math.h>
#include <vector>

using namespace std;

// Global variables
const double Pi = 3.1415926535897, a0 = 0.52918e-8; // a.u -> cm
const int nr_sim = 1000;
// ENERGY
double log_Emin = 0.7, log_Emax = 3.13;
double Emin = pow(10.0,log_Emin);
double Emax = pow(10.0,log_Emax);
int num_bin_E = 20;
double delta_logE = (log_Emax - log_Emin)/num_bin_E;
// ANGLE
double tet_min = 5.0*Pi/180.0;
double tet_max = 175.0*Pi/180.0;
int num_bin_tet = 17;
double delta_tet = 10.0*Pi/180.0;

int cal_energy_index(double E);
int cal_angle_index(double tet);


int main()
{
    ifstream file;
    file.open("6MeV(1000).txt");

    int type;
    double E, teta;
	double E_left, E_right;
	double Ang_left, Ang_right, Ang_mid;

    int count_non_phys = 0;
    int count_ion = 0, N_count_ion;
    int count_cap = 0, N_count_cap;
    int count_bound = 0;

    int b_num = 100;
    double P_ion, P_si, P_ti, P_di;
    double P_cap, P_sc, P_dc;
    double P_non;

	P_si = P_ti = P_di = P_sc = P_dc = 0;

    vector<int> vCount_ion;
    vector<int> vCount_cap;
    vector<int> v_tot;

    vector<int> vCountE_temp(num_bin_E);
    vector<double> vSDCS_E(num_bin_E);

    vector<int> vCountAng_temp(num_bin_tet);
    vector<double> vSDCS_A(num_bin_tet);

    vector< vector<int> > v2D_Count_E_vs_Ang_temp(num_bin_tet, vector<int>(num_bin_E));
    vector< vector<double> > v2D_DDCS_E_A(num_bin_tet, vector<double>(num_bin_E));

	vector< vector<int> > vtype(5);
	vector< vector<double> > vEe(5);
	vector< vector<double> > vteta(5);

	unsigned int index = 0;

    cout << "START READING\n";

    int total = 0;
    while (file >> type >> E >> teta)
    {
        if (!file.good()) break;
        //cout << ++total << ") " << type << " " << E << " " << teta << endl;

		if (type == 7 && E == 7 && teta ==7)
		{
			++index;
			continue;
		}

		vtype[index].push_back(type);
		vEe[index].push_back(E);
		vteta[index].push_back(teta);
    }
	++index;

    file.close();

	double bmin = 0.13;
    double delta_b = 0.2;

	unsigned int v_size = 0;
	unsigned int iter = 0;

	// each orbital of water molecule
	for (int i = 0; i < index; ++i)
	{
		// the number of b values
		v_size = vtype[i].size()/nr_sim;
		cout << endl << iter << endl;
		iter = 0;
		cout << endl << v_size << endl;
		// interval of b-value of orbital 5th
		if (v_size < 20) // v_size == 14 (orbital 5)
		{
			bmin = 0.04;
			delta_b = 0.02;
		}

		// each b-value
		for (int itr_b = 0; itr_b < v_size; ++itr_b)
		{
			// the number of simulation for each b-value
			for (int k = 0; k < nr_sim; ++k)
			{
				type = vtype[i][iter];
				E = vEe[i][iter];
				teta = vteta[i][iter];
				++iter;

				// Ionization
				if (type == 1)
				{
					//cout << teta*180/Pi << " " << cal_angle_index(teta) << endl;
					++count_ion;

					// Counting for SDCS
					if (E >= Emin && E <= Emax)
					{
						++vCountE_temp[cal_energy_index(E)];
					}

					// Counting for DDCS
					if (teta >= tet_min && teta <= tet_max)
					{
						++vCountAng_temp[cal_angle_index(teta)];

						if (E >= Emin && E <= Emax)
						{
							++v2D_Count_E_vs_Ang_temp[cal_angle_index(teta)][cal_energy_index(E)];
						}
					}
				}
				// Capture
				else if (type == 2)
				{
					++count_cap;
				}
				// Remained bound
				else if (type == 3)
				{
					++count_bound;
				}
				// Non-physical
				else
				{
					++count_non_phys;
				}
			}

			// each b-value
			P_ion = double(count_ion)/(nr_sim - count_non_phys);
			P_cap = double(count_cap)/(nr_sim - count_non_phys);
			P_non = 1.0 - P_ion - P_cap;

			P_si += (bmin + delta_b*itr_b)*(2.0*P_ion*P_non)*delta_b;
			P_sc += (bmin + delta_b*itr_b)*(2.0*P_cap*P_non)*delta_b;

			P_ti += (bmin + delta_b*itr_b)*(2.0*P_ion*P_cap)*delta_b;
			P_di += (bmin + delta_b*itr_b)*(2.0*P_ion*P_ion)*delta_b;
			P_dc += (bmin + delta_b*itr_b)*(2.0*P_cap*P_cap)*delta_b;

			for(int z = 0; z < num_bin_E; ++z)
			{
				E_left = pow(10.0, log_Emin + delta_logE*z);
				E_right = pow(10.0, log_Emin + delta_logE*(z + 1));

				vSDCS_E[z] += 2.0*Pi*a0*a0*(bmin + delta_b*itr_b)*delta_b*(double(vCountE_temp[z])/(nr_sim - count_non_phys))/(E_right-E_left);

				vCountE_temp[z] = 0;
			}

			cout << "Hi there!!" << endl;

			for (int t = 0; t < num_bin_tet; ++t)
			{
				Ang_left = tet_min + delta_tet*t;
				Ang_right = tet_min + delta_tet*(t + 1);
				Ang_mid = (Ang_left + Ang_right)/2.0;

				cout << Ang_mid*180/Pi << endl;

				for(int z = 0; z < num_bin_E; ++z)
				{
					E_left = pow(10.0, log_Emin + delta_logE*z);
					E_right = pow(10.0, log_Emin + delta_logE*(z + 1));

					v2D_DDCS_E_A[t][z] += a0*a0*(bmin + delta_b*itr_b)*delta_b*(double(v2D_Count_E_vs_Ang_temp[t][z])/(nr_sim - count_non_phys))/((E_right-E_left)*sin(Ang_mid)*delta_tet);

					v2D_Count_E_vs_Ang_temp[t][z] = 0;
				}
			}

			count_ion = count_cap = count_bound = count_non_phys = 0;

		}
	}

    P_si *= 2.0*Pi*a0*a0;
	P_sc *= 2.0*Pi*a0*a0;

	P_ti *= 2.0*Pi*a0*a0;
	P_di *= 2.0*Pi*a0*a0;
	P_dc *= 2.0*Pi*a0*a0;


    cout << "-----------------------------------------------------------\n";
    cout << "                     TOTAL CROSS SECTION                   \n";
    cout << "                      EQ. in Liamsuliwan                   \n";
    cout << "-----------------------------------------------------------\n";

	cout << "Single ionization : " << P_si << endl;
	cout << "Single capture : " << P_sc << endl;
	cout << "Transfer ionization : " << P_ti << endl;
	cout << "Double ionization : " << P_di << endl;
	cout << "Double capture : " << P_dc << endl;

	cout << "-----------------------------------------------------------\n";
    cout << "            SINGLY DIFFERENTIAL CROSS SECTION              \n";
    cout << "-----------------------------------------------------------\n";

	for (auto sc: vSDCS_E)
	{
		cout << sc << endl;
	}

	cout << "-----------------------------------------------------------\n";
    cout << "           DOUBLY DIFFERENTIAL CROSS SECTION              \n";
    cout << "-----------------------------------------------------------\n";
	/*
	for (int i = 0; i < num_bin_tet; ++i)
	{
		for (int j = 0; j < num_bin_E; ++j)
		{
			cout << v2D_DDCS_E_A[i][j] << endl;
		}
		cout << "-------------------------------" << endl;
	}*/

	for (auto vA : vCountAng_temp)
	{
		cout << vA << endl;
	}

	//**********************OUTPUT***********************

	ofstream fout;
	fout.open("result-6MeV-(1000).txt");

	fout<< "-----------------------------------------------------------\n";
    fout<< "                    TOTAL CROSS SECTION                    \n";
    fout<< "                     EQ. in Liamsuliwan                    \n";
    fout<< "-----------------------------------------------------------\n";

	fout<< "Single ionization : " << P_si << endl;
	fout<< "Single capture : " << P_sc << endl;
	fout<< "Transfer ionization : " << P_ti << endl;
	fout<< "Double ionization : " << P_di << endl;
	fout<< "Double capture : " << P_dc << endl;

	fout<< "-----------------------------------------------------------\n";
    fout<< "            SINGLY DIFFERENTIAL CROSS SECTION              \n";
    fout<< "-----------------------------------------------------------\n";

    double E_mid = 0;
    for(int z = 0; z < num_bin_E; ++z)
    {
        E_left = pow(10.0, log_Emin + delta_logE*z);
        E_right = pow(10.0, log_Emin + delta_logE*(z + 1));
        E_mid = (E_right - E_left)/2.0;

        fout << E_left << " " << vSDCS_E[z] << endl;
    }

	fout<< "-----------------------------------------------------------\n";
    fout<< "           DOUBLY DIFFERENTIAL CROSS SECTION              \n";
    fout<< "-----------------------------------------------------------\n";

    int angle = 0;
	for (int i = 0; i < num_bin_tet; ++i)
	{
	    Ang_left = tet_min + delta_tet*i;
        Ang_right = tet_min + delta_tet*(i + 1);
        Ang_mid = (Ang_left + Ang_right)/2.0;
        angle = Ang_mid*180/Pi + 0.5;

		fout << endl << angle << ")-------------------------------" << endl;
		for (int j = 0; j < num_bin_E; ++j)
		{
			fout<< v2D_DDCS_E_A[i][j] << endl;
		}
	}

	fout.close();

    return 1;
}

int cal_energy_index(double E)
{
    return int((log10(E)-log_Emin)/delta_logE);
}

int cal_angle_index(double tet)
{
    return int((tet - tet_min)/delta_tet);
}
