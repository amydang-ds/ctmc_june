#ifndef _CARBON_H_
#define _CARBON_H_

#include "core.h"

class Carbon
	:public Core
{
protected:

public:
	Carbon();
	Carbon(int m_Z, int m_N);
}; 

#endif