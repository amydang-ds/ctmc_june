#include "carbon.h"

Carbon::Carbon()
{
	m = 12.0*1836;
	Z = 6;
	N = 0;
	etat0 = 1;
	etat1 = 0;
	netat0 = 0;
	netat1 = 0;
	netat = netat0 + netat1*(Z-N-1);
	etat = etat0 + etat1*(Z-N-1);
}
Carbon::Carbon(int m_Z, int m_N)
{
	m = 12.0*1836;
	Z = m_Z;
	N = m_N;
	if (Z == 6 && N == 0)
	{
		etat0 = 1;
		etat1 = 0;
		netat0 = 0;
		netat1 = 0;
	}
	else if (Z == 6 && N == 1)
	{
		etat0 = 2.625;
		etat1 = 1.2996;
		netat0 = 1.770;
		netat1 = 1.1402;
	}
	else if (Z == 6 && N == 2)
	{
		etat0 = 2.164;
		etat1 = 0.9764;
		netat0 = 1.750;
		netat1 = 0.6821;
	}
	else if (Z == 6 && N == 3)
	{
		etat0 = 1.30;
		etat1 = 0.6465;
		netat0 = 1.880;
		netat1 = 0.5547;
	}
	else if (Z == 6 && N == 4)
	{
		etat0 = 1.031;
		etat1 = 0.4924;
		netat0 = 2.0;
		netat1 = 0.4939;
	}
	else if (Z == 6 && N == 5)
	{
		etat0 = 1.065;
		etat1 = 0.48;
		netat0 = 2.13;
		netat1 = 0.4434;
	}
	else if (Z == 6 && N == 6)
	{
		etat0 = 1.179;
		etat1 = 0.4677;
		netat0 = 2.270;
		netat1 = 0.4143;
	}
	else
	{
		cout << "\nNo data for this Z and N value!!!" << endl;
	}
	netat = netat0 + netat1*(Z-N-1);
	etat = etat0 + etat1*(Z-N-1);
}

