#ifndef _IONIZATION_H_
#define _IONIZATION_H_

#include "carbon.h"
#include "water.h"
#include "electron.h"
#include <fstream>
#include <math.h>

class Ionization
{
protected:
	Water t;
	Carbon p;
	Electron e;
	Vector A, dA, B, dB, C, dC;
	double Eb, b;
public:
    Ionization();
	Ionization(double m_Eb, double m_b, double KE, int Nt, int Np);

	void Initialize(double m_Eb, double m_b, double KE, int Nt, int Np);

	void SingleStepRK4(double h);
	void SingleStepRK4B(double h);
	void RK4(int &type, double &Eet_si, double &teta);

	Vector FA(Vector m_A, Vector m_B, Vector m_C);
	Vector FB(Vector m_A, Vector m_B, Vector m_C);

	Vector* backUp();
	void undo(Vector*& ptr);
	void updateC();

	void out();
};

#endif
