#include "vector.h"
Vector::Vector()
{
	x = y = z = 0;
}
Vector::Vector(double m_x, double m_y, double m_z)
{
	x = m_x;
	y = m_y;
	z = m_z;
}

Vector Vector::operator-(const Vector& V)
{
	Vector temp;
	temp.x = x - V.x;
	temp.y = y - V.y;
	temp.z = z - V.z;
	return temp;
}
Vector Vector::operator+(const Vector& V)
{
	Vector temp;
	temp.x = x + V.x;
	temp.y = y + V.y;
	temp.z = z + V.z;
	return temp;
}
Vector Vector::operator*(double d)
{
	Vector temp;
	temp.x = x*d;
	temp.y = y*d;
	temp.z = z*d;
	return temp;
}
Vector Vector::operator*(const Vector& V)
{
	Vector temp;
	temp.x = x * V.x;
	temp.y = y * V.y;
	temp.z = z * V.z;
	return temp;
}

void Vector::set(double m_x, double m_y, double m_z)
{
	x = m_x;
	y = m_y;
	z = m_z;
}
double Vector::module()
{
	return sqrt(x*x+y*y+z*z);
}
double Vector::square()
{
	return (x*x+y*y+z*z);
}

void Vector::in()
{
	cout << "x : ";
	cin >> x;
	cout << "y : ";
	cin >> y;
	cout << "z : ";
	cin >> z;
}
void Vector::out()
{
	cout << "(" << x << "," << y << "," << z << ")";
}