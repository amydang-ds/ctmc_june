#ifndef _PROB_H_
#define _PROB_H_

#include "vector.h"
#include "core.h"
#include "electron.h"
#include "water.h"
#include <fstream>
#include <ctime>
#include <thread>
#include <vector>
#include <string>
#include <mutex>
#include <random>
#include <chrono>
using namespace std;

#include "ionization.h"

void func(vector<int> &type, vector<double> &Ee, vector<double> &teta, double b, int n, int nre);
void checkRecDist();

#endif // _PROB_H_
