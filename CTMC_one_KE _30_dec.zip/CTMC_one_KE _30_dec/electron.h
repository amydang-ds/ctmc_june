#ifndef _ELECTRON_H_
#define _ELECTRON_H_

#include "vector.h"
#include "core.h"
#include <math.h>
#include <random>
#include <chrono>
#include <iostream>
using namespace std;

class Electron
{
private:

public:
	double m;
	int Z;
	Vector r, v;

	Electron();

	double rec(double Eb, Core& core);
	double Pec(double Eb, Core& c, double rec);
	Vector Pec(Core& c, double rec);
	double Eec(Core& c, double rec);
	double rec_max(double Eb, double x, double y, Core& core);

	void Initialize(double Eb, Core& c);
	void out();
};

#endif
