#include "water.h"

Water::Water()
{
	m = 18.0*1836;
	Z = 10;
	N = 9;
	etat0 = 1.792;
	etat1 = 0.4515;
	netat0 = 2.710;
	netat1 = 0.3671;
	netat = netat0 + netat1*(Z-N-1);
	etat = etat0 + etat1*(Z-N-1);
}
Water::Water(int m_Z, int m_N)
{
	m = 18.0*1836;
	Z = m_Z;
	N = m_N;
	if (Z == 10 && N == 9)
	{
		etat0 = 1.792;
		etat1 = 0.4515;
		netat0 = 2.710;
		netat1 = 0.3671;
	}
	else if (Z == 10 && N == 10)
	{
		etat0 = 1.712;
		etat1 = 0.3923;
		netat0 = 2.85;
		netat1 = 0.3469;
	}
	else
	{
		cout << "\nNo data for this Z and N value!!!" << endl;
	}
	netat = netat0 + netat1*(Z-N-1);
	etat = etat0 + etat1*(Z-N-1);
}

