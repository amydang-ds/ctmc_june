#include "ionization.h"

Ionization::Ionization()
{
    Eb = 0;
	b = 0;
}

Ionization::Ionization(double m_Eb, double m_b, double KE, int Nt, int Np)
{
	Eb = m_Eb;
	b = m_b;

	Water m_t(10, Nt);
	t = m_t;

	Carbon m_p(6, Np);
	p = m_p;

	//Initial conditions
	e.Initialize(m_Eb, t);

	double z0 = 50;
	p.r.set(0, m_b, -z0);
	p.v.set(0, 0 , sqrt(2*KE/p.m));

	cout << "\n--------------------------------------\n";
	cout << "INTIAL CONDITIONS\n";
	cout << "Electron : " << endl;
	e.out();
	cout << "\nTarget : " << endl;
	t.out();
	cout << "\nProjectile : " << endl;
	p.out();
	cout << "\n--------------------------------------\n";

	// Relative positions and velocities
	A = e.r - t.r;
	B = t.r - p.r;
	dA = e.v - t.v;
	dB = t.v - p.v;

	Vector O(0.0,0.0,0.0);
	C = O - A - B;
	dC = O - dA - dB;

	cout << "\nVector A : " << endl;
	A.out();
	cout << "\nVector dA : " << endl;
	dA.out();
	cout << "\nVector B : " << endl;
	B.out();
	cout << "\nVector dB : " << endl;
	dB.out();
	cout << "\nVector C : " << endl;
	C.out();
	cout << "\nVector dC : " << endl;
	dC.out();
}

void Ionization::Initialize(double m_Eb, double m_b, double KE, int Nt, int Np)
{
    Eb = m_Eb;
	b = m_b;

	Water m_t(10, Nt);
	t = m_t;

	Carbon m_p(6, Np);
	p = m_p;

	//Initial conditions
	e.Initialize(m_Eb, t);

	double z0 = 50;
	p.r.set(0, m_b, -z0);
	p.v.set(0, 0 , sqrt(2*KE/p.m));

    /*
	cout << "\n--------------------------------------\n";
	cout << "INTIAL CONDITIONS\n";
	cout << "Electron : " << endl;
	e.out();
	cout << "\nTarget : " << endl;
	t.out();
	cout << "\nProjectile : " << endl;
	p.out();
	cout << "\n--------------------------------------\n";
	*/

	// Relative positions and velocities
	A = e.r - t.r;
	B = t.r - p.r;
	dA = e.v - t.v;
	dB = t.v - p.v;

	Vector O(0.0,0.0,0.0);
	C = O - A - B;
	dC = O - dA - dB;

	/*cout << "\nVector A : " << endl;
	A.out();
	cout << "\nVector dA : " << endl;
	dA.out();
	cout << "\nVector B : " << endl;
	B.out();
	cout << "\nVector dB : " << endl;
	dB.out();
	cout << "\nVector C : " << endl;
	C.out();
	cout << "\nVector dC : " << endl;
	dC.out();*/
}

void Ionization::SingleStepRK4(double h)
{
	Vector KA[4], LA[4], KB[4], LB[4];
	Vector O, m_A, m_B, m_C;

	m_A = A;
	m_B = B;
	m_C = O - m_A - m_B;

	KA[0] = dA*h;
	LA[0] = FA(m_A, m_B, m_C)*h;

	KB[0] = dB*h;
	LB[0] = FB(m_A, m_B, m_C)*h;

	m_A = A + KA[0]*(1.0/2.0);
	m_B = B + KB[0]*(1.0/2.0);
	m_C = O - m_A - m_B;

	KA[1] = (dA + LA[0]*(1.0/2.0))*h;
	LA[1] = FA(m_A, m_B, m_C)*h;

	KB[1] = (dB + LB[0]*(1.0/2.0))*h;
	LB[1] = FB(m_A, m_B, m_C)*h;

	m_A = A + KA[1]*(1.0/2.0);
	m_B = B + KB[1]*(1.0/2.0);
	m_C = O - m_A - m_B;

	KA[2] = (dA + LA[1]*(1.0/2.0))*h;
	LA[2] = FA(m_A, m_B, m_C)*h;

	KB[2] = (dB + LB[1]*(1.0/2.0))*h;
	LB[2] = FB(m_A, m_B, m_C)*h;

	m_A = A + KA[2];
	m_B = B + KB[2];
	m_C = O - m_A - m_B;

	KA[3] = (dA + LA[2])*h;
	LA[3] = FA(m_A, m_B, m_C)*h;

	KB[3] = (dB + LB[2])*h;
	LB[3] = FB(m_A, m_B, m_C)*h;

	A = A + (KA[0] + KA[1]*2 + KA[2]*2 +KA[3])*(1.0/6.0);
	dA = dA + (LA[0] + LA[1]*2 + LA[2]*2 +LA[3])*(1.0/6.0);

	B = B + (KB[0] + KB[1]*2 + KB[2]*2 +KB[3])*(1.0/6.0);
	dB = dB + (LB[0] + LB[1]*2 + LB[2]*2 +LB[3])*(1.0/6.0);

	C = O - A - B;
	dC = O - dA - dB;
}

void Ionization::SingleStepRK4B(double h)
{
	Vector KB[4], LB[4];
	Vector O, m_A, m_B, m_C;

	m_A = A;
	m_B = B;
	m_C = O - m_A - m_B;

	KB[0] = dB*h;
	LB[0] = FB(m_A, m_B, m_C)*h;

	m_B = B + KB[0]*(1.0/2.0);
	m_C = O - m_A - m_B;

	KB[1] = (dB + LB[0]*(1.0/2.0))*h;
	LB[1] = FB(m_A, m_B, m_C)*h;

	m_B = B + KB[1]*(1.0/2.0);
	m_C = O - m_A - m_B;

	KB[2] = (dB + LB[1]*(1.0/2.0))*h;
	LB[2] = FB(m_A, m_B, m_C)*h;

	m_B = B + KB[2];
	m_C = O - m_A - m_B;

	KB[3] = (dB + LB[2])*h;
	LB[3] = FB(m_A, m_B, m_C)*h;

	B = B + (KB[0] + KB[1]*2 + KB[2]*2 +KB[3])*(1.0/6.0);
	dB = dB + (LB[0] + LB[1]*2 + LB[2]*2 +LB[3])*(1.0/6.0);

	C = O - A - B;
	dC = O - dA - dB;
}


void Ionization::RK4(int &type, double &Eet_si, double &teta)
{
	double Rcritical, limitDis = 1.0e-3, limitDisPrj = 3.0e-3, vA, vC;
	bool I = 1;
	double met = (e.m*t.m)/(e.m + t.m), mep = (e.m*p.m)/(e.m + p.m), Eet, Eep;

	double tf = 0, h = 0.001;
	while (tf < 10000)
	{
		tf += h;

        vA = dA.module();
        if (vA < 15)
            limitDis = 1.0e-3;
        else
            limitDis = 1.0e-4;

        if (vA*h < limitDis)
            h = limitDis/(dA.module());

        SingleStepRK4(h);

        if (B.module() > 50 && tf > 7.0)
        {
            break;
        }
	}

	vC = dC.module();
    vA = dA.module();

	Eet = vA*vA*(met/2.0) - t.Vc(A.module());
    Eep = vC*vC*(mep/2.0) - p.Vc(C.module());


	//Type of interation
    if (Eet > 0 && Eep > 0) // Ionization
    {
        type = 1;
        Eet_si = Eet*27.2116;
        teta = acos (A.z/A.module());
    }
    else if (Eet > 0 && Eep < 0) // Electron capture
    {
        type = 2;
        teta = Eet_si = 0;
    }
    else if (Eet <= 0 && Eep > 0) // Remained bound to target
    {
        type = 3;
        teta = Eet_si = 0;
    }
    else // Non-physical
    {
        type = 5;
        teta = Eet_si = 0;
    }
}

Vector Ionization::FA(Vector m_A, Vector m_B, Vector m_C)
{
	double mA = m_A.module();
	double mB = m_B.module();
	double mC = m_C.module();

	double termA = ((e.Z/(mA*mA)) * (t.dZc(mA) - t.Vc(mA)));
	double termB = ((1.0/(mB*mB)) * (t.dZc(mB)*p.Zc(mB) + t.Zc(mB)*p.dZc(mB) - p.Zc(mB)*t.Zc(mB)/mB));
	double termC = ((e.Z/(mC*mC)) * (p.dZc(mC) - p.Vc(mC)));

	Vector FA = m_A*(-termC/e.m + (-1.0/e.m + 1.0/t.m)*termA) - m_B*(termC/e.m - (1.0/t.m)*termB);

	return FA;
}
Vector Ionization::FB(Vector m_A, Vector m_B, Vector m_C)
{
	double mA = m_A.module();
	double mB = m_B.module();
	double mC = m_C.module();

	double termA = ((e.Z/(mA*mA)) * (t.dZc(mA) - t.Vc(mA)));
	double termB = ((1.0/(mB*mB)) * (t.dZc(mB)*p.Zc(mB) + t.Zc(mB)*p.dZc(mB) - p.Zc(mB)*t.Zc(mB)/mB));
	double termC = ((e.Z/(mC*mC)) * (p.dZc(mC) - p.Vc(mC)));

	Vector FB = m_A*(termC/p.m - (1.0/t.m)*termA) + m_B*(termC/p.m + (1.0/p.m + 1.0/t.m)*termB);

	return FB;
}

Vector* Ionization::backUp()
{
	Vector* ptr;
	ptr = new Vector[6];
	ptr[0] = A;
	ptr[1] = dA;
	ptr[2] = B;
	ptr[3] = dB;
	ptr[4] = C;
	ptr[5] = dC;
	return ptr;
}
void Ionization::undo(Vector*& ptr)
{
	A = ptr[0];
	dA = ptr[1];
	B = ptr[2];
	dB = ptr[3];
	C = ptr[4];
	dC = ptr[5];
}

void Ionization::out()
{
    cout << Eb << " " << b << endl;
}
