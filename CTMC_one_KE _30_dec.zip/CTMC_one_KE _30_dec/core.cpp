#include "core.h"

Core::Core()
{
	m = 18.0*1836;
	Z = 10;
	N = 9;
	etat0 = 1.792;
	etat1 = 0.4515;
	netat0 = 2.710;
	netat1 = 0.3671;
	netat = netat0 + netat1*(Z-N-1);
	etat = etat0 + etat1*(Z-N-1);
}

double Core::Omega(double rec)
{
	return 1/(netat*(exp(rec*etat)-1)/etat+1);
}
double Core::Zc(double rec)
{
	return Z - N*(1-Omega(rec));
}
double Core::dZc(double rec)
{
	return -N*netat*exp(rec*etat)*Omega(rec)*Omega(rec);
}
double Core::Vc(double rec)
{
	return Zc(rec)/rec;
}

void Core::out()
{
	cout << "m = " << m << endl;
	cout << "Position : ";
	r.out();
	cout << "\nVelocity : ";
	v.out();
	cout << endl;
	cout << "Core : " << Z << " " << N << endl;
	cout << etat0 << " " << etat1 << endl;
	cout << netat0 << " " << netat1 << endl;
	cout << etat << " " << netat << endl;
}