#include "prob.h"

const double Pi = 3.1415926535897;
const double ha = 27.2114;

//Global variables
double KE = 6000.0*12*1e3/ha; // keV/u -> eV -> ha
static double Eb[5] = {12.62/ha, 14.75/ha, 18.51/ha, 32.4/ha, 539.7/ha};

//Protect shared data
mutex mu;


void func(vector<int> &type, vector<double> &Ee, vector<double> &teta, double b, int n, int nre)
{
	int m_type;
    double m_Ee, m_teta;

    unsigned int i;

	Ionization *arr = NULL;
	arr = new Ionization[n];

	for (i = 0; i < n; i++)
    {
        cout << i << ") ";
        arr[i].Initialize(Eb[nre], b, KE, 9, 0);
        //arr[i].out();
    }

    for (i = 0; i < n; i++)
    {
        cout << i << ") ";
        arr[i].RK4(m_type, m_Ee, m_teta);

        //mu.lock();
        type.push_back(m_type);
        Ee.push_back(m_Ee);
        teta.push_back(m_teta);
        //mu.unlock();
    }

    delete[] arr;
    cout << "\nFINISHED FUNC\n";
}

void checkRecDist()
{
    // CHECK REC DISTRIBUTION
	double Eb = 12.62/27.2114;

	Water A;
	A.out();

	cout << "----------------------------" << endl;
	Electron e;

	ofstream file;
	file.open("rec.txt");

	for (int i = 0; i < 10000; i++)
	{
		file << e.rec(Eb, A) << endl;
	}

	file.close();
	cout << "\nEnd" << endl;
}
