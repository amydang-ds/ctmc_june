#include "electron.h"

const double unit = 27.2114;
const double Eb1 = 12.62/unit;
const double Eb2 = 14.75/unit;
const double Eb3 = 18.51/unit;
const double Eb4 = 32.4/unit;
const double Eb5 = 539.7/unit;

// Instantiating the real uniform distribution object
unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
std::default_random_engine generator(seed);
std::uniform_real_distribution<double> distribution(0.0,1.0);

Electron::Electron()
{
	m = 1;
	Z = -1;
}

double Electron::rec_max(double Eb, double x, double y, Core& core)
{
	double a, b, c;
	double epsi = 1.0e-14;
	a = x;
	b = y;
	while (abs(b-a) >= epsi)
	{
		c = (a + b)/2.0;
		if ((core.Vc(a) - Eb)*(core.Vc(c) - Eb) > 0)
			a = c;
		else
			b = c;
	}
	c = a;
	return c;
}

//Rejection sampling
double Electron::rec(double Eb, Core& core)
{
	//return 0.025;
	//return 0.7130;

	double rand_num = 0.0;

	double a = 0.01, b = 10000.0;
	double rmax = rec_max(Eb, a, b, core);

	double r[10000];
	r[0] = 1.0e-7;

	double delta = (rmax - r[0])/10000.0;
	for (int i = 0; i < 10000-1; i++)
	{
		r[i+1] = r[i] + delta;
	}

	// Finding ymax
	double ytemp, ymax = 1.0e-6;
	double mec = m*core.m/(m+core.m);

	for (int i = 0; i < 10000; i++)
	{
		ytemp = mec*r[i]*r[i]*sqrt(2*mec*(-abs(Eb)+core.Vc(r[i])));
		if (ytemp > ymax)
			ymax = ytemp;
	}

	// Finding r2
	double r1 = 0.03, r2;
	if (Eb == Eb1 || Eb == Eb2 || Eb == Eb3 || Eb == Eb4)
		r2 = 0.9*rmax;
	else if (Eb == Eb5)
		r2 = 0.87*rmax;

	double rec_temp, Ptemp;

	while (1)
	{
		rand_num = distribution(generator);
		rec_temp = rand_num*rmax;
		//cout << rec_temp/rmax << endl;
		if (rec_temp >= r1 && rec_temp <=r2)
		{
			Ptemp = mec*rec_temp*rec_temp*sqrt(2*mec*(-abs(Eb)+core.Vc(rec_temp)));
			rand_num = distribution(generator);
			if (Ptemp/ymax > rand_num)
				break;
		}
	}
	return rec_temp;
}

//Relative momentum value of an Eb electron to a core
double Electron::Pec(double Eb, Core& c, double rec)
{
	double mec = m*c.m/(m+c.m);
	return sqrt(2*mec*(-abs(Eb)+c.Vc(rec)));
}

//Relative momentum vector of an electron with rec
Vector Electron::Pec(Core& c, double rec)
{
	double mec = m*c.m/(m+c.m);
	return (v - c.v)*mec;
}

//Relative Energy of this electron and the core c
double Electron::Eec(Core& c, double rec)
{
	double mec = m*c.m/(m+c.m);
	return (Pec(c, rec).square())/(2*mec) - c.Vc(rec);
}

//Initialize conditions of electron and its bounding core
void Electron::Initialize(double Eb, Core& c)
{
	//Random a value of rec
	double d_rec = this->rec(Eb, c);

	// Instantiating the real uniform distribution object
	//std::default_random_engine generator;
	//std::uniform_real_distribution<double> distribution(0.0,1.0);
	double rand_num = 0.0;

	//Random spherical coordinates
	double Pi = 3.1415926535897;
	rand_num = distribution(generator);
	double teta = rand_num*Pi;
	double phi = rand_num*2.0*Pi;
	double neta = rand_num*2.0*Pi;

	/*double teta = 0.2221;
	double phi = 5.7978;
	double neta = 0.0289;*/

	//Vector rec
	Vector vector_rec(sin(teta)*cos(phi), sin(teta)*sin(phi), cos(teta));
	vector_rec = vector_rec*d_rec;

	double mec = m*c.m/(m+c.m);
	double Mec = m + c.m;

	//Relative velocity electron vs core
	Vector vec(-sin(phi)*cos(neta)-cos(phi)*cos(teta)*sin(neta), cos(phi)*cos(neta)-sin(phi)*cos(teta)*sin(neta), sin(teta)*sin(neta));
	vec = vec*(Pec(Eb, c, d_rec)/mec);

	//Initial positions of electron and its bounding core
	r = vector_rec*(c.m/Mec);
	c.r = vector_rec*(m/Mec);

	//Initial velocity
	v = vec*(c.m/Mec);
	c.v = vec*(m/Mec);

	cout << "Intialized electron and its bounding core! =))" << endl;
}

void Electron::out()
{
	cout << "m = " << m << endl;
	cout << "Position : ";
	r.out();
	cout << "\nVelocity : ";
	v.out();
	cout << endl;
}
