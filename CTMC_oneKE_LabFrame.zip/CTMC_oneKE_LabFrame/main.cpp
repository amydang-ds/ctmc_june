#include "prob.h"

int main()
{
    // DETERMINE THE NUMBER OF THREAD
    unsigned int nr_threads = thread::hardware_concurrency();
    cout << nr_threads << " concurrent threads are supported.\n";

    //MULTI-THREADING
	vector<thread> th;

    //nr_threads = 8;
    unsigned int nr_b = 31;
    unsigned int nr_per_thread = 1000;
    double bmin = 0.13;
    double delta_b = 0.2;
    double b;

    vector<vector <int> > type(nr_b*5);
    vector<vector <double> > Ee(nr_b*5);
    vector<vector <double> > teta(nr_b*5);

	unsigned int index = 0;

	for (int nr_e = 0; nr_e < 5; ++nr_e)
	{
		// 12.62
		if (nr_e == 0)
		{
			nr_b = 31;
			bmin = 0.13;
			delta_b = 0.2;
		}
		// 14.75
		else if (nr_e == 1)
		{
			nr_b = 31;
			bmin = 0.13;
			delta_b = 0.2;
		}
		// 18.51
		else if (nr_e == 2)
		{
			nr_b = 26;
			bmin = 0.13;
			delta_b = 0.2;
		}
		// 32.4
		else if (nr_e == 3)
		{
			nr_b = 21;
			bmin = 0.13;
			delta_b = 0.2;
		}
		// 539.7
		else if (nr_e == 4)
		{
			nr_b = 14;
			bmin = 0.04;
			delta_b = 0.02;
		}

		//Launch a group of threads
		for (int i = 0; i < nr_b; ++i)
		{
			b = bmin + delta_b*i;
			cout << "b value " << b << endl;

			th.push_back(thread(func, ref(type[index]), ref(Ee[index]), ref(teta[index]), b, nr_per_thread, nr_e));
			++index;
		}
	}

	//Join the threads with the main thread
	for(auto &t : th)
	{
		t.join();
	}


    ofstream file;
	file.open("6MeV(1000)-std.txt");
	unsigned int tot_num = 0;

    //vector of vector
	for (int i = 0; i < index; ++i)
    {
        // values of each vector
        for (int j = 0; j < nr_per_thread; ++j)
        {
            ++tot_num;
            cout << tot_num << ") " << type[i][j] << " " << Ee[i][j] << " " << teta[i][j] << endl;
            file << type[i][j] << " " << Ee[i][j] << " " << teta[i][j] << endl;
        }

		if (i == (30) || i == (61) || i == (87) || i == (108))
		{
		    cout << 7 << " " << 7 << " " << 7 << endl;
			file << 7 << " " << 7 << " " << 7 << endl;
		}
    }

    file.close();

	cout << "\nHAPPY ENDING =)\n";

    return 0;
}
