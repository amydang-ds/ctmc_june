#include "ionization.h"

Ionization::Ionization()
{
    Eb = 0;
	b = 0;
}

Ionization::Ionization(double m_Eb, double m_b, double KE, int Nt, int Np)
{
	Eb = m_Eb;
	b = m_b;

	Water m_t(10, Nt);
	t = m_t;

	Carbon m_p(6, Np);
	p = m_p;

	//Initial conditions
	e.Initialize(m_Eb, t);

	double z0 = 50;
	p.r.set(0, m_b, -z0);
	p.v.set(0, 0 , sqrt(2*KE/p.m));

	cout << "\n--------------------------------------\n";
	cout << "INTIAL CONDITIONS\n";
	cout << "Electron : " << endl;
	e.out();
	cout << "\nTarget : " << endl;
	t.out();
	cout << "\nProjectile : " << endl;
	p.out();
	cout << "\n--------------------------------------\n";

	// Relative positions and velocities
	UpdateABC();
	UpdateDiffABC();
}

void Ionization::Initialize(double m_Eb, double m_b, double KE, int Nt, int Np)
{
    Eb = m_Eb;
	b = m_b;

	Water m_t(10, Nt);
	t = m_t;

	Carbon m_p(6, Np);
	p = m_p;

	//Initial conditions
	e.Initialize(m_Eb, t);

	double z0 = 50;
	p.r.set(0, m_b, -z0);
	p.v.set(0, 0 , sqrt(2*KE/p.m));

	cout << "\n--------------------------------------\n";
	cout << "INTIAL CONDITIONS\n";
	cout << "Electron : " << endl;
	e.out();
	cout << "\nTarget : " << endl;
	t.out();
	cout << "\nProjectile : " << endl;
	p.out();
	cout << "\n--------------------------------------\n";

	// Relative positions and velocities
	UpdateABC();
	UpdateDiffABC();
}

void Ionization::SingleStepRK4LabFrame(double h)
{
	Vector Kp[4], Lp[4], Kt[4], Lt[4], Ke[4], Le[4];
	Vector m_A, m_B, m_C;

	m_A = A;
	m_B = B;
	m_C = C;

    //**************** 1ST ORDER ***************
    //-------------- Position -----------
	Kp[0] = p.v*h;
	Kt[0] = t.v*h;
	Ke[0] = e.v*h;

    //-------------- Velocity -----------
	Lp[0] = Fp(m_B, m_C)*h;
	Lt[0] = Ft(m_A, m_B)*h;
	Le[0] = Fe(m_A, m_C)*h;

    //-------------- Relative Position -----------
	m_A = A + (Ke[0]- Kt[0])*0.5;
	m_B = B + (Kp[0]- Kt[0])*0.5;
	m_C = C + (Ke[0]- Kp[0])*0.5;

	//**************** 2ND ORDER ***************
    //-------------- Position -----------
	Kp[1] = (p.v + Lp[0]*0.5)*h;
	Kt[1] = (t.v + Lt[0]*0.5)*h;
	Ke[1] = (e.v + Le[0]*0.5)*h;

    //-------------- Velocity -----------
	Lp[1] = Fp(m_B, m_C)*h;
	Lt[1] = Ft(m_A, m_B)*h;
	Le[1] = Fe(m_A, m_C)*h;

    //-------------- Relative Position -----------
	m_A = A + (Ke[1]- Kt[1])*0.5;
	m_B = B + (Kp[1]- Kt[1])*0.5;
	m_C = C + (Ke[1]- Kp[1])*0.5;

    //**************** 3RD ORDER ***************
    //-------------- Position -----------
	Kp[2] = (p.v + Lp[1]*0.5)*h;
	Kt[2] = (t.v + Lt[1]*0.5)*h;
	Ke[2] = (e.v + Le[1]*0.5)*h;

    //-------------- Velocity -----------
	Lp[2] = Fp(m_B, m_C)*h;
	Lt[2] = Ft(m_A, m_B)*h;
	Le[2] = Fe(m_A, m_C)*h;

    //-------------- Relative Position -----------
	m_A = A + (Ke[2]- Kt[2]);
	m_B = B + (Kp[2]- Kt[2]);
	m_C = C + (Ke[2]- Kp[2]);

	//**************** 4TH ORDER ***************
    //-------------- Position -----------
	Kp[3] = (p.v + Lp[2])*h;
	Kt[3] = (t.v + Lt[2])*h;
	Ke[3] = (e.v + Le[2])*h;

    //-------------- Velocity -----------
	Lp[3] = Fp(m_B, m_C)*h;
	Lt[3] = Ft(m_A, m_B)*h;
	Le[3] = Fe(m_A, m_C)*h;

    //**************** FINALLY ***************
    //-------------- Position -----------
	p.r = p.r + (Kp[0] + Kp[1]*2.0 + Kp[2]*2.0 +Kp[3])*(1.0/6.0);
	t.r = t.r + (Kt[0] + Kt[1]*2.0 + Kt[2]*2.0 +Kt[3])*(1.0/6.0);
	e.r = e.r + (Ke[0] + Ke[1]*2.0 + Ke[2]*2.0 +Ke[3])*(1.0/6.0);

    //-------------- Velocity -----------
    p.v = p.v + (Lp[0] + Lp[1]*2.0 + Lp[2]*2.0 +Lp[3])*(1.0/6.0);
    t.v = t.v + (Lt[0] + Lt[1]*2.0 + Lt[2]*2.0 +Lt[3])*(1.0/6.0);
    e.v = e.v + (Le[0] + Le[1]*2.0 + Le[2]*2.0 +Le[3])*(1.0/6.0);

	UpdateABC();
}

void Ionization::SingleStepRK4Proj(double h)
{
	Vector Kp[4], Lp[4], Kt[4], Lt[4], Ke[4], Le[4];
	Vector m_A, m_B, m_C;

    m_A = A;
	m_B = B;
	m_C = C;

    //**************** 1ST ORDER ***************
    //-------------- Position -----------
	Kp[0] = p.v*h;
	Kt[0] = O;
	Ke[0] = O;

    //-------------- Velocity -----------
	Lp[0] = Fp(m_B, m_C)*h;
	Lt[0] = Ft(m_A, m_B)*h;
	Le[0] = O;

    //-------------- Relative Position -----------
	m_A = A + (Ke[0]- Kt[0])*0.5;
	m_B = B + (Kp[0]- Kt[0])*0.5;
	m_C = C + (Ke[0]- Kp[0])*0.5;

	//**************** 2ND ORDER ***************
    //-------------- Position -----------
	Kp[1] = (p.v + Lp[0]*0.5)*h;
	Kt[1] = O;
	Ke[1] = O;

    //-------------- Velocity -----------
	Lp[1] = Fp(m_B, m_C)*h;
	Lt[1] = Ft(m_A, m_B)*h;
	Le[1] = O;

    //-------------- Relative Position -----------
	m_A = A + (Ke[1]- Kt[1])*0.5;
	m_B = B + (Kp[1]- Kt[1])*0.5;
	m_C = C + (Ke[1]- Kp[1])*0.5;

    //**************** 3RD ORDER ***************
    //-------------- Position -----------
	Kp[2] = (p.v + Lp[1]*0.5)*h;
	Kt[2] = O;
	Ke[2] = O;

    //-------------- Velocity -----------
	Lp[2] = Fp(m_B, m_C)*h;
	Lt[2] = Ft(m_A, m_B)*h;
	Le[2] = O;

    //-------------- Relative Position -----------
	m_A = A + (Ke[2]- Kt[2]);
	m_B = B + (Kp[2]- Kt[2]);
	m_C = C + (Ke[2]- Kp[2]);

	//**************** 4TH ORDER ***************
    //-------------- Position -----------
	Kp[3] = (p.v + Lp[2])*h;
	Kt[3] = O;
	Ke[3] = O;

    //-------------- Velocity -----------
	Lp[3] = Fp(m_B, m_C)*h;
	Lt[3] = Ft(m_A, m_B)*h;
	Le[3] = O;

    //**************** FINALLY ***************
    //-------------- Position -----------
	p.r = p.r + (Kp[0] + Kp[1]*2.0 + Kp[2]*2.0 +Kp[3])*(1.0/6.0);
	t.r = t.r + (Kt[0] + Kt[1]*2.0 + Kt[2]*2.0 +Kt[3])*(1.0/6.0);
	e.r = e.r + (Ke[0] + Ke[1]*2.0 + Ke[2]*2.0 +Ke[3])*(1.0/6.0);

    //-------------- Velocity -----------
    p.v = p.v + (Lp[0] + Lp[1]*2.0 + Lp[2]*2.0 +Lp[3])*(1.0/6.0);
    t.v = t.v + (Lt[0] + Lt[1]*2.0 + Lt[2]*2.0 +Lt[3])*(1.0/6.0);
    e.v = e.v + (Le[0] + Le[1]*2.0 + Le[2]*2.0 +Le[3])*(1.0/6.0);

	UpdateABC();
}


void Ionization::RK4(int &type, double &Eet_si, double &teta)
{
    cout << "HELLO!!" << endl;
	ofstream file;
	file.open("EEang.txt");

	double angle;

	double Rcritical, limitDis = 1.0e-2, limitDisPrj = 3.0e-1, ve, vA, vC;
	bool I = 1;
	double met = (e.m*t.m)/(e.m + t.m), mep = (e.m*p.m)/(e.m + p.m), Eet, Eep;

	double tf = 0, h = 0.001, i = 1;
	while (tf < 10000)
	{
		tf += h;
		if (I)
		{
		    Rcritical = (sqrt(p.Zc(C.module()))+sqrt(t.Zc(A.module())))*(sqrt(p.Zc(C.module()))+sqrt(t.Zc(A.module())))/Eb;
			if (B.module() > Rcritical)
			{
				I = 1;
			}
			else
			{
				I = 0;
				continue;
			}

			if (p.v.module()*h > limitDisPrj)
            {
                h = limitDisPrj/p.v.module();
            }

			SingleStepRK4Proj(h);
		}
		else
		{
            if (e.v.module()*h > limitDis)
            {
                h = limitDis/e.v.module();
            }

			SingleStepRK4LabFrame(h);

			ve = e.v.module();
			if (ve <= 15)
				limitDis = 1.0e-2;
			else if (ve > 15 && ve < 22)
				limitDis = 4.0e-3;
            else if (ve >= 22 && ve < 28)
                limitDis = 2.0e-3;
            else
                limitDis = 1.0e-3;

            if (B.module() > 50 || p.r.module() > 50)
            {
                break;
            }

		}

		i++;

		//cout << i << endl;

		UpdateDiffABC();

		vC = dC.module();
		vA = dA.module();

		//TEST
		Eet = vA*vA*(met/2.0) - t.Vc(A.module());
		Eep = vC*vC*(mep/2.0) - t.Vc(C.module());
		angle = acos (e.r.z/e.r.module());
		file << tf << "\t" << Eet << "\t" << Eep << "\t" << angle*180.0/3.14 << endl;
	}

	file.close();

	Eet = vA*vA*(met/2.0) - t.Vc(A.module());
    Eep = vC*vC*(mep/2.0) - t.Vc(C.module());

    cout << Eet << "  " << Eep << endl;

	//Type of interation
    if (Eet > 0 && Eep > 0) // Ionization
    {
        type = 1;
        Eet_si = Eet*27.2116;
        teta = acos (e.r.z/e.r.module());
    }
    else if (Eet > 0 && Eep < 0) // Electron capture
    {
        type = 2;
        teta = Eet_si = 0;
    }
    else if (Eet <= 0 && Eep > 0) // Remained bound to target
    {
        type = 3;
        teta = Eet_si = 0;
    }
    else // Non-physical
    {
        type = 5;
        teta = Eet_si = 0;
    }
}

Vector Ionization::Fp(Vector m_B, Vector m_C)
{
	double mB = m_B.module();
	double mC = m_C.module();

	double termB = ((1.0/(mB*mB)) * (t.dZc(mB)*p.Zc(mB) + t.Zc(mB)*p.dZc(mB) - p.Zc(mB)*t.Zc(mB)/mB));
	double termC = ((e.Z/(mC*mC)) * (p.dZc(mC) - p.Vc(mC)));

	Vector Fp = (O - m_B*termB - m_C*termC)*(1.0/p.m);

	return Fp;
}

Vector Ionization::Ft(Vector m_A, Vector m_B)
{
	double mA = m_A.module();
	double mB = m_B.module();

	double termA = ((e.Z/(mA*mA)) * (t.dZc(mA) - t.Vc(mA)));
	double termB = ((1.0/(mB*mB)) * (t.dZc(mB)*p.Zc(mB) + t.Zc(mB)*p.dZc(mB) - p.Zc(mB)*t.Zc(mB)/mB));

	Vector Ft = (O - m_B*termB - m_A*termA)*(1.0/t.m);

	return Ft;
}

Vector Ionization::Fe(Vector m_A, Vector m_C)
{
	double mA = m_A.module();
	double mC = m_C.module();

	double termA = ((e.Z/(mA*mA)) * (t.dZc(mA) - t.Vc(mA)));
	double termC = ((e.Z/(mC*mC)) * (p.dZc(mC) - p.Vc(mC)));

	Vector Fe = (O - m_A*termA + m_C*termC)*(1.0/e.m);

	return Fe;
}

void Ionization::UpdateABC()
{
    A = e.r - t.r;
    B = p.r - t.r;
    C = e.r - p.r;
}

void Ionization::UpdateDiffABC()
{
    dA = e.v - t.v;
    dB = p.v - t.v;
    dC = e.v - p.v;
}

void Ionization::out()
{
    cout << Eb << " " << b << endl;
}
