#ifndef _CORE_H_
#define _CORE_H_

#include <math.h>
#include "vector.h"
#include <iostream>
using namespace std;

class Core
{
protected:
	double etat0, netat0, etat1, netat1, etat, netat;
public:
	int Z, N;
	double m;
	Vector r, v;

	Core();

	virtual double Omega(double rec);
	virtual double Zc(double rec);
	virtual double dZc(double rec);
	virtual double Vc(double rec);

	virtual void out();
};

#endif